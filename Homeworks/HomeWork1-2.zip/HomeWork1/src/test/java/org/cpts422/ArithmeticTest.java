package org.cpts422;

import org.junit.jupiter.api.BeforeEach;

import static org.junit.jupiter.api.Assertions.*;

class ArithmeticTest {



    // Task: write normal & robust boundary tests for the methods sum(), difference() and quotient()
    // You may or may not use setup and teardown methods.

}